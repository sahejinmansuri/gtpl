
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to GTPL</title>
<link rel="shortcut icon" href="images/favicon_icon.png" />
	<link rel='stylesheet' type='text/css' href='css/menu.css' />
	<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
    	<script type='text/javascript' src='menu_jquery.js'></script>
        


        
<!---for inputype--->
<script>
function autotab(original,destination){
if (original.getAttribute&&original.value.length==original.getAttribute("maxlength"))
destination.focus()
}
</script>
<!---end for inputype--->
<link rel="stylesheet" type="text/css" href="css/gtpl_style.css" />

<link href="src/skdslider.css" rel="stylesheet">
<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery('#demo1').skdslider({'delay':5000, 'animationSpeed': 2000,'showNextPrev':true,'showPlayButton':true,'autoSlide':true,'animationType':'fading'});
			jQuery('#demo2').skdslider({'delay':5000, 'animationSpeed': 1000,'showNextPrev':true,'showPlayButton':false,'autoSlide':true,'animationType':'sliding'});
			jQuery('#demo3').skdslider({'delay':5000, 'animationSpeed': 2000,'showNextPrev':true,'showPlayButton':true,'autoSlide':true,'animationType':'fading'});
			
			jQuery('#responsive').change(function(){
			  $('#responsive_wrapper').width(jQuery(this).val());
			});
			
		});
</script>		
	<script typ="text/javascript">
 var namepattern=/^[a-zA-Z]+$/
 var phonepattern = /^\d{10}$/
 var emailpattern =/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.([a-zA-Z]{2,4})$/
 var emailpattern2 =/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)*$/
 var idpattern=/^\d{6}$/;

function validateForm()
{

 var x=document.forms["form1"]["txtuname"];
 if (x.value=="")
   {
 
  document.getElementById('pointuname').innerHTML="Please Enter Your Username.";
    x.focus();
  return false;
   }
 document.getElementById('pointuname').innerHTML='';

 x=document.form1.txtpwd;
 if(x.value=="")
 {
  x.value="";
  document.getElementById('pointpwd').innerHTML="Please Enter Your Password";
  x.focus();
  return false;
 }
 document.getElementById('pointpwd').innerHTML="";

}
</script>	


</head>
<body>
<div id="header_wrapper">

<div id="header">
<div class="logo"><a href="index.html"><img src="images/logo.png" width="148" height="55" / border="0"></a></div>

<div class="cont_right">
<a href="login.php"><button class="signin_button">Sign In</button></a>
<a href="caf.html"><button class="register_button">Register</button></a>
<div class="mob_icon"><span></span>+91-9727-633-633<br />
+91-1800-2330-233</div>

</div>
<div class="clear"></div>
</div>


<div id='cssmenu'>
<ul>
   <li><a href='index.html'><span>HOME</span></a></li>
   <li class='has-sub'><a href='#'><span>TELEVISION</span></a>
      <ul>
         <li><a href='standard_definition.html'><span>Standard Definition</span></a>
         </li>
         <li class='last'><a href='heigh_definition.html'><span>High Definition</span></a></li>
         <li class='last'><a href='packages.html'><span>Digital Cable TV Packages</span></a></li>
<li><a href='tvschedule.html'><span>TV schedule</span></a></li>
      </ul>
   </li>
   <li class='has-sub'><a href='#'><span>BROADBAND</span></a>
   
   <ul>
         <li><a href='plan/plan1/index.html'><span>plan Selector</span></a></li>
         <li class='last'><a href='#'><span>View Plans</span></a></li>
      </ul>
   
     <!--- <ul>
         <li><a href='#'><span>About</span></a></li>
         <li class='last'><a href='#'><span>Location</span></a></li>
      </ul>---->
   </li>
   <li><a href='#'><span>CAREER</span></a>
   	 <ul>
         <li><a href='career.html'><span>People</span></a></li>
         <li><a href='#'><span>Current Openings</span></a></li>
      </ul>
   
   </li>
       <li><a href='#'><span>ABOUT US</span></a>
      <ul>
         <li><a href='corporate_philosophy.html'><span>Corporate Philosophy</span></a>
         </li>
         <li class='last'><a href='leaders.html'><span>Leaders</span></a></li>
         <li class='last'><a href='timeline.html'><span>Timeline</span></a></li>
      </ul>
       </li>
         <li><a href='customersupport.html'><span>CUSTOMER SUPPORT</span></a></li>
      <li class='last'><a href='contactus.html'><span>CONTACT US</span></a></li>
   


</ul>
</div>

</div>

<div class="pack_wrapper">
<div class="wrapper">
<div id="message" style="margin-left:400px;">
<?php 
if(isset($_REQUEST['msg'])){
	echo $_REQUEST['msg'];
}
?>
</div>
<form method="post" action="authenticate.php" name="form1">
<div class="login">

<div width="150"><i style="color:red;" id="pointuname"></i> </div>
<div class="login_inner">
<div class="login_icon"><img src="images/login_man.png" /></div>
<input type="text" name="txtuname" placeholder="User Name" />

</div>
<div width="150"><i style="color:red;" id="pointpwd"></i> </div>
<div class="login_inner">
<div class="login_icon"><img src="images/lock.png" width="16" height="20" style="margin-top:2px" /></div>
<input type="password" name="txtpwd" placeholder="Password" />
</div>
<div class="login_input">

<input type="radio" class="login" id="radio1" name="radiog_lite">
<label class="login_1" for="radio1"><br />Broadband</label>

<input type="radio" class="login" id="radio2" name="radiog_lite">
<label class="login_1" for="radio2"><br /> Digital Cable TV</label>

</div>

<!--<div class="login_inner">
<div class="login_icon"><img src="images/select_hand.png" width="20" height="24" /></div>

<div class="lg_select">
<select>
<option selected="selected" value="">Select</option>
<option>Broadband</option>
<option>Digital Cable TV</option>
</select>



</div>
	
</div>-->

<div class="login_option">
</div>

<div class="login_button">
<button type="submit" onClick="return validateForm()" name="submit">Login</button>
</div>

<div class="forgotpass"><a href="#"> Forgot your Password?</a></div>

</div>
</form>


</div>
<div class="clear"></div>
</div>



<!----footer start ---->
<div id="footer">
<div class="wrapper">
<div class="ft_menu1">
<h4>IMPORTANT LINK</h4>
<ul>
<li class="first"><a href="#">Home</a></li>
<li><a href="#">Television</a></li>
<li><a href="#">BROADBAND</a></li>
<li><a href="#">CAREER</a></li>
<li><a href="#">ABOUT US</a></li>
<li><a href="#">CONTACT US</a></li>
</ul>                           
</div> 

<div class="ft_menu1">
<h4>IMPORTANT LINK</h4>
<ul>
<li class="first"><a href="#">Get an HD Connection</a></li>
<li><a href="#">View Television Packages</a></li>
<li><a href="#">View Broadband Packages</a></li>
<li><a href="#">Register your SET TOP BOX</a></li>
<li><a href="#"> Current Openings</a></li>
<li><a href="#">Customer Support</a></li>
</ul>                           
</div>

<div class="ft_contact">
<h4>CONTACT US</h4>
<p style="padding-top:12px;">2nd Floor, Sahajanand Shopping Centre, 
Opposite Swaminarayan Temple, 
Shahibaug, Ahmedabad-380004<br />
E-mail :  ccare@gtpl.net<br />
Contact No. 9727633633</p>

</div>


</div>
<div class="clear"></div>
</div>
<!----footer end---->

<!----design by start---->
<div id="designby">
<div class="wrapper">

<div class="powerby">
<p>© 2014. GTPL Hathway Pvt. Ltd. All Rights Reserved. | Powered by : GTPL</p>
</div>

<div class="developby">
<p>Design & develop by <a href="http://attuneinfocom.com/" target="_blank">Attune Infocom Pvt.Ltd</a></p>
</div>
</div>
<div class="clear"></div>
</div>
<!----design by end---->

</body>
</html>
