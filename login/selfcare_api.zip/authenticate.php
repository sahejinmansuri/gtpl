<?php
//@include("auth.php");
include('functions.php');

$username =$_POST['txtuname'];
$password = $_POST['txtpwd'];

$authenticateuser = AuthenticateUser($username ,$password );

if(is_object($authenticateuser))
{
	session_start();
	$_SESSION['username']=$_POST['txtuname'];
	$_SESSION['password']=$_POST['txtpwd'];
	$cust_no = 'BB1770';
	$customer_info = GetCustomerInfo($cust_no);
	
	if($customer_info != "")
	{
		$_SESSION['first_name'] = $customer_info->FIRSTNAME;
		$_SESSION['last_name'] = $customer_info->LASTNAME;	
		$_SESSION['customer_no'] = $cust_no;	
	}
	//echo "AuthenticateUser Successfully Done.";
	header('location:summary.php');
	
}
else
{	
	$msg=error_code($authenticateuser);
	header('location:login.php?msg='.$msg);	
}
?>