<?php 
@include("auth.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to GTPL</title>
<link rel="shortcut icon" href="images/favicon_icon.png" />
<link rel='stylesheet' type='text/css' href='css/menu.css' />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
<script type='text/javascript' src='menu_jquery.js'></script>
<link rel="stylesheet" type="text/css" href="css/gtpl_style.css" />
<!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>
<body>

<div class="clear"></div>
<!----banner---->
<!--<div class="banner_main">
<div class="brn"><img src="images/add_banner.jpg" width="1300" height="300" /></div>
</div>-->
<!----end banner---->
<!----section1 start---->

</div>
<!----section1 end---->
<!----footer start ---->
<div id="footer">
  <div class="wrapper">
    <div class="ft_menu1">
      <h4>IMPORTANT LINK</h4>
      <ul>
        <li class="first"><a href="#">Home</a></li>
        <li><a href="#">Television</a></li>
        <li><a href="#">BROADBAND</a></li>
        <li><a href="#">CAREER</a></li>
        <li><a href="#">ABOUT US</a></li>
        <li><a href="#">CONTACT US</a></li>
      </ul>
    </div>
    <div class="ft_menu1">
      <h4>IMPORTANT LINK</h4>
      <ul>
        <li class="first"><a href="#">Get an HD Connection</a></li>
        <li><a href="#">View Television Packages</a></li>
        <li><a href="#">View Broadband Packages</a></li>
        <li><a href="#">Register your SET TOP BOX</a></li>
        <li><a href="#"> Current Openings</a></li>
        <li><a href="#">Customer Support</a></li>
      </ul>
    </div>
    <div class="ft_contact">
      <h4>CONTACT US</h4>
      <p style="padding-top:12px;">2nd Floor, Sahajanand Shopping Centre, 
        Opposite Swaminarayan Temple, 
        Shahibaug, Ahmedabad-380004<br />
        E-mail :  ccare@gtpl.net<br />
        Contact No. 9727633633</p>
    </div>
  </div>
  <div class="clear"></div>
</div>
<!----footer end---->
<!----design by start---->
<div id="designby">
  <div class="wrapper">
    <div class="powerby">
      <p>© 2014. GTPL Hathway Pvt. Ltd. All Rights Reserved. | Powered by : GTPL</p>
    </div>
    <div class="developby">
      <p>Design & develop by <a href="http://attuneinfocom.com/" target="_blank">Attune Infocom Pvt.Ltd</a></p>
    </div>
  </div>
  <div class="clear"></div>
</div>
<!----design by end---->
</body>
</html>
