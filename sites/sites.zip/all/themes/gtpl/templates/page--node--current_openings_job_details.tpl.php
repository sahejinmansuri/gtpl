<?php print render($page['content']);
print render($page['content_channel']); ?>
    